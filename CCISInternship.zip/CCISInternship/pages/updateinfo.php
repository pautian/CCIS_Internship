<?
session_start();
if (file_exists('includes/database.php')) { include_once('includes/database.php'); }
if (file_exists('../includes/database.php')) { include_once('../includes/database.php'); }


$studentid = $_GET['studentid'];


$firstname = GetValue('SELECT firstname FROM tblstudent WHERE studentid='.$studentid);
$middleinitial = GetValue('SELECT middleinitial FROM tblstudent WHERE studentid='.$studentid);
$middlename = GetValue('SELECT middlename FROM tblstudent WHERE studentid='.$studentid);
$lastname = GetValue('SELECT lastname FROM tblstudent WHERE studentid='.$studentid);
$gender = GetValue('SELECT gender FROM tblstudent WHERE studentid='.$studentid);
$email = GetValue('SELECT email FROM tblstudent WHERE studentid='.$studentid);
$contactno = GetValue('SELECT contactno FROM tblstudent WHERE studentid='.$studentid);
$address = GetValue('SELECT address FROM tblstudent WHERE studentid='.$studentid);
?>
<!--<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">-->

    <style>
       
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
        }

        input,
        select,
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
        }

        select {
            cursor: pointer;
        }

        textarea {
            resize: vertical;
        }

        button {
            background-color: #4caf50;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #45a049;
        }
    </style>
</head>


<form>
    <input placeholder="Input firstname" value="<?=$firstname?>" type="text" id="firstname">
    <br>
    <input placeholder="Input middlename" value="<?=$middlename?>" type="text" id="middlename">
    <br>
    <input placeholder="Input middleinitial" value="<?=$middleinitial?>" type="text" id="middleinitial">
    <br>
    <input placeholder="Input lastname" value="<?=$lastname?>" type="text" id="lastname">
    <br>
    <?php
    $options = array(
        0 => 'Select Gender',
        'M' => 'Male',
        'F' => 'Female'
    );
    ?>
    <select id="gender">
        <?php
        foreach ($options as $value => $label) {
            $selected = ($gender == $value) ? 'selected="selected"' : '';
            echo '<option value="' . $value . '" ' . $selected . '>' . $label . '</option>';
        }
        ?>
    </select>
    <br>
    <input placeholder="Input your email address" value="<?=$email?>" type="text" id="email">
    <br>
    <input placeholder="Input your contact number" value="<?=$contactno?>" type="text" id="contactno">
    <br>
    <textarea placeholder="Input your permanent address" id="address"><?=$address?></textarea>
    <br>
    
</form>
<div align="right"><button class="btn btn-primary btm-sm" onclick="update_info(<?=$studentid?>);">Update</button></div>