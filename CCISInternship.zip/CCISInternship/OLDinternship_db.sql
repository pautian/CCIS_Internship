/*
SQLyog Ultimate v8.55 
MySQL - 5.5.5-10.4.24-MariaDB : Database - internship_db
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`internship_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `internship_db`;

/*Table structure for table `tblaccomplishment_photo` */

DROP TABLE IF EXISTS `tblaccomplishment_photo`;

CREATE TABLE `tblaccomplishment_photo` (
  `idnum` int(11) NOT NULL AUTO_INCREMENT,
  `studentid` int(11) DEFAULT 0,
  `picture` varchar(256) DEFAULT '',
  `picturedate` datetime DEFAULT NULL,
  `description` varchar(256) DEFAULT '',
  PRIMARY KEY (`idnum`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tblaccomplishment_photo` */

/*Table structure for table `tblaccomplishmentreport` */

DROP TABLE IF EXISTS `tblaccomplishmentreport`;

CREATE TABLE `tblaccomplishmentreport` (
  `reportid` int(11) NOT NULL AUTO_INCREMENT,
  `studentid` int(11) DEFAULT 0,
  `title` varchar(128) DEFAULT '',
  `datefrom` date DEFAULT NULL,
  `dateto` date DEFAULT NULL,
  `timein` time DEFAULT NULL,
  `timeout` time DEFAULT NULL,
  `totalhours` int(11) DEFAULT NULL,
  `description` varchar(500) DEFAULT '',
  PRIMARY KEY (`reportid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tblaccomplishmentreport` */

/*Table structure for table `tblapplication` */

DROP TABLE IF EXISTS `tblapplication`;

CREATE TABLE `tblapplication` (
  `applicationid` int(11) NOT NULL AUTO_INCREMENT,
  `applicationdatetime` datetime DEFAULT NULL,
  `studentid` int(11) DEFAULT 0,
  `companyid` int(11) DEFAULT 0,
  `status` tinyint(1) DEFAULT 0,
  `is_reject` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`applicationid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `tblapplication` */

insert  into `tblapplication`(`applicationid`,`applicationdatetime`,`studentid`,`companyid`,`status`,`is_reject`) values (1,'2023-11-27 18:01:34',2,1,1,0);

/*Table structure for table `tblapplication_tmp` */

DROP TABLE IF EXISTS `tblapplication_tmp`;

CREATE TABLE `tblapplication_tmp` (
  `idnum` int(11) NOT NULL AUTO_INCREMENT,
  `studentid` int(11) DEFAULT 0,
  `courseid` int(11) DEFAULT 0,
  `sectionid` int(11) DEFAULT 0,
  `companyid` int(11) DEFAULT 0,
  `applicationdate` datetime DEFAULT NULL,
  `is_endorse` tinyint(1) DEFAULT 0,
  `is_reject` tinyint(1) DEFAULT 0,
  `is_selected` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`idnum`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

/*Data for the table `tblapplication_tmp` */

insert  into `tblapplication_tmp`(`idnum`,`studentid`,`courseid`,`sectionid`,`companyid`,`applicationdate`,`is_endorse`,`is_reject`,`is_selected`) values (4,2,1,3,7,'2023-11-27 15:57:45',0,1,0),(5,2,1,3,1,'2023-11-27 15:57:50',1,0,1),(6,2,1,3,3,'2023-11-27 15:57:55',0,1,0),(7,3,1,3,1,'2023-11-27 16:05:59',1,0,0),(8,3,1,3,8,'2023-11-27 16:06:07',0,0,0),(9,3,1,3,4,'2023-11-27 16:06:12',0,0,0),(10,4,1,3,5,'2023-11-27 16:13:38',0,0,0),(11,4,1,3,1,'2023-11-27 16:13:42',1,0,0),(12,4,1,3,2,'2023-11-27 16:13:46',1,0,0),(13,1,1,3,2,'2023-11-27 17:35:03',1,0,0),(14,1,1,3,9,'2023-11-27 17:35:07',0,0,0),(15,1,1,3,1,'2023-11-27 17:35:11',1,0,0);

/*Table structure for table `tblcompany` */

DROP TABLE IF EXISTS `tblcompany`;

CREATE TABLE `tblcompany` (
  `companyid` int(11) NOT NULL AUTO_INCREMENT,
  `companycode` varchar(128) DEFAULT '',
  `companyname` varchar(256) DEFAULT '',
  `signatory` varchar(128) DEFAULT '',
  `position` varchar(256) DEFAULT '',
  `address` longtext DEFAULT NULL,
  `notarizationdate` date DEFAULT NULL,
  `max_apply` int(11) DEFAULT 0,
  `applicants` int(11) DEFAULT 0,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `notify_date` date DEFAULT NULL,
  `moa_img` varchar(255) DEFAULT '',
  `company_link` varchar(400) DEFAULT '',
  PRIMARY KEY (`companyid`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

/*Data for the table `tblcompany` */

insert  into `tblcompany`(`companyid`,`companycode`,`companyname`,`signatory`,`position`,`address`,`notarizationdate`,`max_apply`,`applicants`,`start_date`,`end_date`,`notify_date`,`moa_img`,`company_link`) values (1,'','LIBERTY INSURANCE CORP.','MELISSA T. MILCA','SENIOR MANAGER FOR HUMAN RESOURCES AND ADMINISTRATION','JCS Building No. 119 Dela Rosa cor. C. Palanca Sts. Legaspi Village Makati City','2023-04-14',0,0,'2023-11-21','2023-12-21','2023-11-21','','https://www.google.com/'),(2,'','FASTSEND MOBILE SOLUTIONS CORPORATION','ROBERT MICHAEL P. CRESPO','CEO','Unit 7E PDCP Bankc Centre V.A. Rufino St. Salcedo Village Bel-Air City of Makati','2023-04-14',100,0,'2023-11-21','2023-12-21','2023-11-21','',''),(3,'','SHORETEL PHILIPPINES CORP.','JOHN EARVIN V. FLORES','TERRITORY ACCOUNT MANAGER','12th Floor Multinational Bancorporation Centre 6805 Ayala Ave. Makati City','2023-04-14',0,0,'2023-11-21','2023-12-21','2023-11-21','',''),(4,'','DEVXPRESS IT SOLUTIONS','FRANCIS S. MANAIG','OWNER','Calamba City Laguna','2023-04-14',0,0,'2023-11-21','2024-01-21','2023-12-21','',''),(5,'','DYIPPAY REVOLUTION CORPORATION','ENRIQUE TAN ','CEO','Baras TBI Bulacan State University Malolos Bulacan','2023-04-14',0,0,'2023-11-21','2023-12-21','2023-11-21','',''),(6,'','DAHUA TECHNOLOGY (HK) LIMITED (PHILIPPINE REPRESENTATIVE OFFICE)','DIANNE ALYSSA F. CARDINO','HR & ADMIN MANAGER','Unit 1919 One Park Drive cor. 9th Ave. Taguig Metro Manila','2023-05-04',0,0,'2023-09-21','2025-12-20','2025-11-20','',''),(7,'','PHILIPPINE AIR FORCE','1LT. HERBERT MARK T. MADURO PAF','DIRECTOR FOR CMO','Col. Jesus Villamor Air Base','2023-05-04',0,0,'2023-11-21','2023-12-21','2023-11-21','',''),(8,'','ECO GLOBAL CONSULTING INC.','ELENITA C. DELA ROSA','FOUNDER & CEO','20th Floor Zuellig Building Makati Ave. cor Paseo De Roxas Makati City','2023-05-04',0,0,'2023-11-21','2023-12-21','2023-11-21','',''),(9,'','BARKERO IT CONSULTANCY ','VINCENT MARTIN NICDAO HERMOSURA','CEO','1129 Angel Linao Street cor Pres. Quirino Ave. Manila','2023-05-18',0,0,'2022-11-01','2023-12-01','2023-11-01','',''),(10,'','TAOCROWD INC.','BERNICE BUENAFE','COMPANY REPRESENTAIVE','Unit 707 One Park Drive 11th Drive cor. 95h Ave. Bonifacio Global City, Fort Bonifacio, Taguig City','2020-05-18',0,0,'2023-11-21','2023-12-21','2023-11-21','','');

/*Table structure for table `tblcompany_ojt` */

DROP TABLE IF EXISTS `tblcompany_ojt`;

CREATE TABLE `tblcompany_ojt` (
  `idnum` int(11) NOT NULL AUTO_INCREMENT,
  `companyid` int(11) DEFAULT 0,
  `studentid` int(11) DEFAULT 0,
  `courseid` int(11) DEFAULT 0,
  `sectionid` int(11) DEFAULT 0,
  `is_endorse` int(1) DEFAULT 0,
  `is_ojt` tinyint(1) DEFAULT 0,
  `is_end` tinyint(1) DEFAULT 0,
  `is_cancel` tinyint(1) DEFAULT 0,
  `start_intern` datetime DEFAULT NULL,
  `end_intern` datetime DEFAULT NULL,
  `is_complete` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`idnum`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `tblcompany_ojt` */

insert  into `tblcompany_ojt`(`idnum`,`companyid`,`studentid`,`courseid`,`sectionid`,`is_endorse`,`is_ojt`,`is_end`,`is_cancel`,`start_intern`,`end_intern`,`is_complete`) values (1,1,2,1,3,1,1,0,0,'2023-11-27 18:02:58',NULL,0);

/*Table structure for table `tblcourse` */

DROP TABLE IF EXISTS `tblcourse`;

CREATE TABLE `tblcourse` (
  `courseid` int(11) NOT NULL AUTO_INCREMENT,
  `coursecode` varchar(128) DEFAULT '',
  `coursename` varchar(256) DEFAULT '',
  `departmentid` int(11) DEFAULT NULL,
  `max_apply` int(11) DEFAULT 0,
  `applicants` int(11) DEFAULT 0,
  PRIMARY KEY (`courseid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `tblcourse` */

insert  into `tblcourse`(`courseid`,`coursecode`,`coursename`,`departmentid`,`max_apply`,`applicants`) values (1,'BSIT','Bachelor of Science in Information Technology',1,100,0),(2,'BSCS','Bachelor of Science in Computer Science',1,100,0);

/*Table structure for table `tbldepartment` */

DROP TABLE IF EXISTS `tbldepartment`;

CREATE TABLE `tbldepartment` (
  `departmentid` int(11) NOT NULL AUTO_INCREMENT,
  `departmentcode` varchar(128) DEFAULT '',
  `departmentname` varchar(256) DEFAULT '',
  PRIMARY KEY (`departmentid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `tbldepartment` */

insert  into `tbldepartment`(`departmentid`,`departmentcode`,`departmentname`) values (1,'CCIS','College of Computer and Information Sciences');

/*Table structure for table `tblendorsement` */

DROP TABLE IF EXISTS `tblendorsement`;

CREATE TABLE `tblendorsement` (
  `endorsementid` int(11) NOT NULL AUTO_INCREMENT,
  `courseid` int(11) DEFAULT 0,
  `sectionid` int(11) DEFAULT 0,
  `companyid` int(11) DEFAULT 0,
  `is_selected` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`endorsementid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tblendorsement` */

/*Table structure for table `tblfaculty` */

DROP TABLE IF EXISTS `tblfaculty`;

CREATE TABLE `tblfaculty` (
  `facultyid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(128) DEFAULT '',
  `middlename` varchar(128) DEFAULT '',
  `lastname` varchar(128) DEFAULT '',
  `username` varchar(128) DEFAULT '',
  `email` varchar(128) DEFAULT '',
  `password` varchar(128) DEFAULT '',
  `sectionid` int(11) DEFAULT 0,
  `departmentid` int(11) DEFAULT 0,
  `courseid` int(11) DEFAULT 0,
  `usertype` int(11) DEFAULT 0,
  `imagefaculty` varchar(256) DEFAULT '',
  `is_approve` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`facultyid`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

/*Data for the table `tblfaculty` */

insert  into `tblfaculty`(`facultyid`,`firstname`,`middlename`,`lastname`,`username`,`email`,`password`,`sectionid`,`departmentid`,`courseid`,`usertype`,`imagefaculty`,`is_approve`) values (1,'Coordinator','','Coordinator','coordinator','evangelistabeah3@gmail.com','1b207465eac83b5d4b12e335faa0b53a',0,0,1,1,'',0),(2,'Teacher 4-1','','LastnamePaula','Teacher 4-1','evangelistabeah3@gmail.com','1b207465eac83b5d4b12e335faa0b53a',1,0,1,0,'',0),(3,'Teacher 4-2','','LastnamePaula','Teacher 4-2','evangelistabeah3@gmail.com','1b207465eac83b5d4b12e335faa0b53a',2,0,1,0,'',0),(4,'Teacher 4-3','','LastnamePaula','Teacher 4-3','evangelistabeah3@gmail.com','1b207465eac83b5d4b12e335faa0b53a',3,0,1,0,'',0),(5,'Teacher 4-4','','LastnamePaula','Teacher 4-4','evangelistabeah3@gmail.com','1b207465eac83b5d4b12e335faa0b53a',4,0,1,0,'',0),(6,'Teacher 4-5','','LastnamePaula','Teacher 4-5','evangelistabeah3@gmail.com','1b207465eac83b5d4b12e335faa0b53a',5,0,1,0,'',0),(7,'Teacher 4-1N','','LastnamePaula','Teacher 4-1N','evangelistabeah3@gmail.com','1b207465eac83b5d4b12e335faa0b53a',6,0,1,0,'',0),(8,'Teacher 4-2N','','LastnamePaula','Teacher 4-2N','evangelistabeah3@gmail.com','1b207465eac83b5d4b12e335faa0b53a',7,0,1,0,'',0),(9,'Teacher 3-1','','LastnamePaula','Teacher 3-1','evangelistabeah3@gmail.com','1b207465eac83b5d4b12e335faa0b53a',8,0,2,0,'',0),(10,'Teacher 3-2','','LastnamePaula','Teacher 3-2','evangelistabeah3@gmail.com','1b207465eac83b5d4b12e335faa0b53a',9,0,2,0,'',0),(11,'Teacher 3-3','','LastnamePaula','Teacher 3-3','evangelistabeah3@gmail.com','1b207465eac83b5d4b12e335faa0b53a',10,0,2,0,'',0),(12,'Teacher 3-4','','LastnamePaula','Teacher 3-4','evangelistabeah3@gmail.com','1b207465eac83b5d4b12e335faa0b53a',11,0,2,0,'',0),(13,'Teacher 3-5','','LastnamePaula','Teacher 3-5','evangelistabeah3@gmail.com','1b207465eac83b5d4b12e335faa0b53a',12,0,2,0,'',0),(14,'Teacher 3-1N','','LastnamePaula','Teacher 3-1N','evangelistabeah3@gmail.com','1b207465eac83b5d4b12e335faa0b53a',13,0,2,0,'',0);

/*Table structure for table `tblinterntype` */

DROP TABLE IF EXISTS `tblinterntype`;

CREATE TABLE `tblinterntype` (
  `typeid` int(11) DEFAULT NULL,
  `type` varchar(128) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tblinterntype` */

insert  into `tblinterntype`(`typeid`,`type`) values (1,'On-site Internship'),(2,'Online Internship'),(3,'Hybrid Internship');

/*Table structure for table `tblrating` */

DROP TABLE IF EXISTS `tblrating`;

CREATE TABLE `tblrating` (
  `ratingid` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(256) DEFAULT '',
  `studentid` int(11) DEFAULT 0,
  `companyid` int(11) DEFAULT 0,
  `datetime_rate` datetime DEFAULT NULL,
  `rating` int(11) DEFAULT 0,
  PRIMARY KEY (`ratingid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `tblrating` */

insert  into `tblrating`(`ratingid`,`description`,`studentid`,`companyid`,`datetime_rate`,`rating`) values (1,'Random Rating',1,6,'2023-11-27 17:48:38',3),(2,'Random Rating',1,7,'2023-11-27 17:48:38',5),(3,'Random Rating',1,8,'2023-11-27 17:48:38',3),(4,'Random Rating',1,9,'2023-11-27 17:48:38',2),(5,'Random Rating',1,10,'2023-11-27 17:48:38',1);

/*Table structure for table `tblreset` */

DROP TABLE IF EXISTS `tblreset`;

CREATE TABLE `tblreset` (
  `resetid` int(11) NOT NULL AUTO_INCREMENT,
  `studentid` int(11) DEFAULT 0,
  `token` varchar(128) DEFAULT '',
  `is_inactive` tinyint(1) DEFAULT 0,
  `time_now` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`resetid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `tblreset` */

insert  into `tblreset`(`resetid`,`studentid`,`token`,`is_inactive`,`time_now`) values (1,2,'64955',1,NULL);

/*Table structure for table `tblreset_f` */

DROP TABLE IF EXISTS `tblreset_f`;

CREATE TABLE `tblreset_f` (
  `resetid` int(11) NOT NULL AUTO_INCREMENT,
  `facultyid` int(11) DEFAULT 0,
  `token` varchar(128) DEFAULT '',
  `is_inactive` tinyint(1) DEFAULT 0,
  `time_now` datetime DEFAULT NULL,
  PRIMARY KEY (`resetid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tblreset_f` */

/*Table structure for table `tblsection` */

DROP TABLE IF EXISTS `tblsection`;

CREATE TABLE `tblsection` (
  `sectionid` int(11) NOT NULL AUTO_INCREMENT,
  `sectioncode` varchar(128) DEFAULT '',
  `courseid` int(11) DEFAULT 0,
  `max_apply` int(11) DEFAULT 40,
  `max_slots` int(11) DEFAULT 7,
  `applicants` int(11) DEFAULT 0,
  PRIMARY KEY (`sectionid`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

/*Data for the table `tblsection` */

insert  into `tblsection`(`sectionid`,`sectioncode`,`courseid`,`max_apply`,`max_slots`,`applicants`) values (1,'4-1',1,40,7,0),(2,'4-2',1,40,7,0),(3,'4-3',1,40,7,1),(4,'4-4',1,40,7,0),(5,'4-5',1,40,7,0),(6,'4-1N',1,40,7,0),(7,'4-2N',1,40,7,0),(8,'3-1',2,40,7,0),(9,'3-2',2,40,7,0),(10,'3-3',2,40,7,0),(11,'3-4',2,40,7,0),(12,'3-5',2,40,7,0),(13,'3-1N',2,40,7,0);

/*Table structure for table `tblstudent` */

DROP TABLE IF EXISTS `tblstudent`;

CREATE TABLE `tblstudent` (
  `studentid` int(11) NOT NULL AUTO_INCREMENT,
  `studentno` varchar(128) DEFAULT '',
  `dateofbirth` date DEFAULT NULL,
  `typeid` tinyint(1) DEFAULT 0,
  `resume` varchar(256) DEFAULT '',
  `cv` varchar(256) DEFAULT '',
  `bio` longtext DEFAULT NULL,
  `skills` longtext DEFAULT NULL,
  `other_info` longtext DEFAULT NULL,
  `consent` varchar(256) DEFAULT '',
  `profilepic` varchar(256) DEFAULT '',
  `firstname` varchar(128) DEFAULT '',
  `middleinitial` char(10) DEFAULT '',
  `middlename` varchar(128) DEFAULT '',
  `lastname` varchar(128) DEFAULT '',
  `gender` char(1) DEFAULT '',
  `email` varchar(128) DEFAULT '',
  `contactno` varchar(128) DEFAULT '',
  `address` varchar(256) DEFAULT '',
  `studentpassword` varchar(128) DEFAULT '',
  `is_president` tinyint(1) DEFAULT 0,
  `departmentid` int(11) DEFAULT 0,
  `courseid` int(11) DEFAULT 0,
  `sectionid` int(11) DEFAULT 0,
  `companyid` int(11) DEFAULT 0,
  `facultyid` int(11) DEFAULT 0,
  `is_endorse` tinyint(1) DEFAULT 0,
  `is_ojt` tinyint(1) DEFAULT 0,
  `is_end` tinyint(1) DEFAULT 0,
  `is_updated` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`studentid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `tblstudent` */

insert  into `tblstudent`(`studentid`,`studentno`,`dateofbirth`,`typeid`,`resume`,`cv`,`bio`,`skills`,`other_info`,`consent`,`profilepic`,`firstname`,`middleinitial`,`middlename`,`lastname`,`gender`,`email`,`contactno`,`address`,`studentpassword`,`is_president`,`departmentid`,`courseid`,`sectionid`,`companyid`,`facultyid`,`is_endorse`,`is_ojt`,`is_end`,`is_updated`) values (1,'2020-01437-MN-0','2002-06-15',0,'MED.png','Minimalist (2).png','never give up',NULL,NULL,'Minimalist (2).png','me.jpg','Paula','','','Evangelista','F','evangelistabeah3@gmail.com','09064669085','017 zone 1Santo Domingo','1b207465eac83b5d4b12e335faa0b53a',0,0,1,3,0,0,0,0,0,1),(2,'2020-01925-MN-0','2023-01-01',3,'MED.png','Minimalist (2)(1).png','ehehehe','GREAT AT EVERYTHING\n','THE BEST INTERN CANDIDATE EVER','CONSENT.png','JHANNEX.png','Anthony','','','Olasiman','M','jhannexolaco88@gmail.com','09999999999','Rizal','1b207465eac83b5d4b12e335faa0b53a',1,0,1,3,1,0,1,1,0,1),(3,'2020-09990-MN-0','2002-03-27',3,'MED.png','Minimalist.png','ayoko na magcapstone','good typing skills','Great at backend coding','CONSENT.png','owen.png','Owen Alexis','','','Anicas','M','owenelexis0327@gmail.com','09215545074','Pasig City','1b207465eac83b5d4b12e335faa0b53a',0,0,1,3,0,0,0,0,0,1),(4,'2020-01438-MN-0','2001-09-29',0,'MED.png','Minimalist (3).png','I luv mark',NULL,NULL,'CONSENT.png','TINE.png','Kristine','','','Castillo','F','castillokristine29@gmail.com','09499684712','Montalban, Rizal','1b207465eac83b5d4b12e335faa0b53a',0,0,1,3,0,0,0,0,0,1),(5,'2020-099677-MN-0','2002-07-15',0,'','',NULL,NULL,NULL,'','mackie.jpg','','','','','','','','','1b207465eac83b5d4b12e335faa0b53a',0,0,0,0,0,0,0,0,0,0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
