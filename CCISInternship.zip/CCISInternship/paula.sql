/*
SQLyog Ultimate v8.55 
MySQL - 5.5.5-10.4.28-MariaDB : Database - internship_db
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `tblfaculty` */

DROP TABLE IF EXISTS `tblfaculty`;

CREATE TABLE `tblfaculty` (
  `facultyid` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(128) DEFAULT '',
  `middlename` varchar(128) DEFAULT '',
  `lastname` varchar(128) DEFAULT '',
  `username` varchar(128) DEFAULT '',
  `email` varchar(128) DEFAULT '',
  `password` varchar(128) DEFAULT '',
  `sectionid` int(11) DEFAULT 0,
  `departmentid` int(11) DEFAULT 0,
  `courseid` int(11) DEFAULT 0,
  `usertype` int(11) DEFAULT 0,
  `imagefaculty` varchar(256) DEFAULT '',
  `is_approve` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`facultyid`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

/*Data for the table `tblfaculty` */

insert  into `tblfaculty`(`facultyid`,`firstname`,`middlename`,`lastname`,`username`,`email`,`password`,`sectionid`,`departmentid`,`courseid`,`usertype`,`imagefaculty`,`is_approve`) values (1,'Coordinator','','Coordinator','coordinator','evangelistabeah3@gmail.com','1b207465eac83b5d4b12e335faa0b53a',0,0,1,1,'',0),(2,'Teacher 4-1','','LastnamePaula','Teacher 4-1','evangelistabeah3@gmail.com','1b207465eac83b5d4b12e335faa0b53a',1,0,1,0,'',0),(3,'Teacher 4-2','','LastnamePaula','Teacher 4-2','evangelistabeah3@gmail.com','1b207465eac83b5d4b12e335faa0b53a',2,0,1,0,'',0),(4,'Teacher 4-3','','LastnamePaula','Teacher 4-3','evangelistabeah3@gmail.com','1b207465eac83b5d4b12e335faa0b53a',3,0,1,0,'',0),(5,'Teacher 4-4','','LastnamePaula','Teacher 4-4','evangelistabeah3@gmail.com','1b207465eac83b5d4b12e335faa0b53a',4,0,1,0,'',0),(6,'Teacher 4-5','','LastnamePaula','Teacher 4-5','evangelistabeah3@gmail.com','1b207465eac83b5d4b12e335faa0b53a',5,0,1,0,'',0),(7,'Teacher 4-1N','','LastnamePaula','Teacher 4-1N','evangelistabeah3@gmail.com','1b207465eac83b5d4b12e335faa0b53a',6,0,1,0,'',0),(8,'Teacher 4-2N','','LastnamePaula','Teacher 4-2N','evangelistabeah3@gmail.com','1b207465eac83b5d4b12e335faa0b53a',7,0,1,0,'',0),(9,'Teacher 3-1','','LastnamePaula','Teacher 3-1','evangelistabeah3@gmail.com','1b207465eac83b5d4b12e335faa0b53a',8,0,2,0,'',0),(10,'Teacher 3-2','','LastnamePaula','Teacher 3-2','evangelistabeah3@gmail.com','1b207465eac83b5d4b12e335faa0b53a',9,0,2,0,'',0),(11,'Teacher 3-3','','LastnamePaula','Teacher 3-3','evangelistabeah3@gmail.com','1b207465eac83b5d4b12e335faa0b53a',10,0,2,0,'',0),(12,'Teacher 3-4','','LastnamePaula','Teacher 3-4','evangelistabeah3@gmail.com','1b207465eac83b5d4b12e335faa0b53a',11,0,2,0,'',0),(13,'Teacher 3-5','','LastnamePaula','Teacher 3-5','evangelistabeah3@gmail.com','1b207465eac83b5d4b12e335faa0b53a',12,0,2,0,'',0),(14,'Teacher 3-1N','','LastnamePaula','Teacher 3-1N','evangelistabeah3@gmail.com','1b207465eac83b5d4b12e335faa0b53a',13,0,2,0,'',0);

/*Table structure for table `tblsection` */

DROP TABLE IF EXISTS `tblsection`;

CREATE TABLE `tblsection` (
  `sectionid` int(11) NOT NULL AUTO_INCREMENT,
  `sectioncode` varchar(128) DEFAULT '',
  `courseid` int(11) DEFAULT 0,
  `max_apply` int(11) DEFAULT 40,
  `max_slots` int(11) DEFAULT 7,
  `applicants` int(11) DEFAULT 0,
  PRIMARY KEY (`sectionid`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

/*Data for the table `tblsection` */

insert  into `tblsection`(`sectionid`,`sectioncode`,`courseid`,`max_apply`,`max_slots`,`applicants`) values (1,'4-1',1,40,7,0),(2,'4-2',1,40,7,0),(3,'4-3',1,40,7,0),(4,'4-4',1,40,7,0),(5,'4-5',1,40,7,0),(6,'4-1N',1,40,7,0),(7,'4-2N',1,40,7,0),(8,'3-1',2,40,7,0),(9,'3-2',2,40,7,0),(10,'3-3',2,40,7,0),(11,'3-4',2,40,7,0),(12,'3-5',2,40,7,0),(13,'3-1N',2,40,7,0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
