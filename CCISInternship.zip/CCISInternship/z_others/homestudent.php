<?
session_start();
    if (file_exists('includes/database.php')) { include_once('includes/database.php'); }
    if (file_exists('../includes/database.php')) { include_once('../includes/database.php'); }
	$select = mysqli_query($db_connection, "SELECT * FROM tblstudent WHERE studentid = '$_SESSION[studentid]'  ");
    $count = mysqli_num_rows($select);

    if($count == 0) {
      header("location:./");		
    }
?>

<html lang="en">
	<head>
		<title>Student | Panel</title>
		<meta charset="utf-8">
		<link rel="icon" href="images/PUPLogo.png" type="image/ico">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="studentcss/css/style.css">
		
		<style>
		#sidebar{
			background-color:rgb(128,0,0);
		}
		
		/* CSS OF BLAIRE */
		@import url('https://fonts.googleapis.com/css2?family=Raleway:wght@600&family=Roboto&display=swap');
			.content {
			font-family: 'Raleway', sans-serif;
			margin: 0;
			padding: 0;
			background-image: url('images/darkbg.png');
			background-size: cover;
			background-repeat: no-repeat;
			overflow: hidden; /* prevent scrollbar when modal appears */
		}
		.container {
			display: flex;
			height: 100vh;
		}

		.sidebar {
			width: 120px; /* initial width */
			background-color: maroon;
			height: 100%;
			padding: 20px;
			transition: width 0.3s ease; /* animation effect */
			display: flex;
			flex-direction: column;
			align-items: center;
			box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
		}

		.sidebar.minimized {
			width: 40px; /* minimized width */
		}

		.logo {
			width: 40px;
			margin-bottom: 30px;
		}

		.sidebar.minimized .logo {
			margin-bottom: 0; /* remove margin when minimized */
		}

		.sidebar p {
			margin-top: 20px; /* space above the <p> element, adjust as needed */
		}

		.icon {
			height: 40px;
			width: 40px;
			margin-bottom: 15px;
			transition: transform 0.3s ease;
		}

		.icon img {
			width: 30px;  /* adjust this value as needed */
			height: 30px; /* adjust this value as needed */
			display: block;
			margin: 0 auto; /* this will center the image inside the div if the div is wider than the image */
			filter: invert(1);
		}


		.icon:hover {
			transform: scale(1.1);
		}

		.content {
			flex: 1;
			padding: 20px;
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;
			color: white;
			text-align: center;;
			font-weight: bold;
		}

		.headline {
			font-size: 55px; /* Adjust based on your requirements */
			line-height: 1.2; /* Provides spacing between lines */
			max-width: 800px; /* Limits the width to wrap the text into roughly three lines; adjust as needed */
			text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5); /* Adds a shadow effect */
			margin-bottom: 20px; /* Add space below the headline for better separation */
			white-space: pre-line; /* Ensures text respects newline characters */
			overflow-wrap: break-word; /* Breaks long words to prevent overflow */
			margin-top: 0px;
			letter-spacing: 20px;

		}

		button {
			padding: 10px 20px;
			border: white;
			border-style: solid;
			color: #000;
			cursor: pointer;
			transition: background-color 0.3s ease;
		}

		button:hover {
			background-color: #ddd;
		}

		#closeButton {
			position: absolute;
			top: 10px;
			right: 10px;
			background-color: #000;
			color: #FFF;
			font-weight: bold;
			border-radius: 50%;
			width: 30px;
			height: 30px;
			line-height: 30px;
			text-align: center;
		}

		.modal {
			display: none;
			position: absolute;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
			background-color: rgba(0, 0, 0, 0.5);
			display: flex;
			justify-content: center;
			align-items: center;
			backdrop-filter: blur(10px);
		}

		.infographic {
			width: 70%;
			height: 70%;
			background-color: #FFF;
			padding: 20px;
			box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.3);
		}
		</style>
	<script src="js/sweetalert.min.js"></script>
	<script src="js/tinybox.js"></script>
	<style>
		.tbox {position:absolute;  display:none; padding:14px 17px; z-index:900}
		.tinner {padding:15px; -moz-border-radius:5px; border-radius:5px; background:#fff url(images/preload.gif) no-repeat 50% 50%; border-right:1px solid #333; border-bottom:1px solid #333;}
		.tmask {position:absolute; display:none; top:0px; left:0px; height:100%; width:100%; background:#000; z-index:800}
		.tclose {position:absolute; top:0px; right:0px; width:30px; height:30px; cursor:pointer; background:url(images/close.png) no-repeat}
		.tclose:hover {background-position:0 -30px}
		
		#error {background:#ff6969; color:#fff; text-shadow:1px 1px #cf5454; border-right:1px solid #000; border-bottom:1px solid #000; padding:0}
		#error .tcontent {padding:10px 14px 11px; border:1px solid #ffb8b8; -moz-border-radius:5px; border-radius:5px}
		#success {background:#2ea125; color:#fff; text-shadow:1px 1px #1b6116; border-right:1px solid #000; border-bottom:1px solid #000; padding:10; -moz-border-radius:0; border-radius:0}
		#bluemask {background:#4195aa}
		#frameless {padding:0}
		#frameless .tclose {left:6px}
		
  
	</style>
	<script>
    function loadPage(url,elementId) {
		if (window.XMLHttpRequest) {
				xmlhttp=new XMLHttpRequest();
		} else {
			xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		}   
		xmlhttp.onreadystatechange=function() {
			if (xmlhttp.readyState==4 && xmlhttp.status==200) {
				document.getElementById(elementId).innerHTML="";
				document.getElementById(elementId).innerHTML=xmlhttp.responseText;	
			}
		}  
		xmlhttp.open("GET",url,true);
		xmlhttp.send();	   
    }
	
	function param(w,h) {
		var width  = w;
		var height = h;
		var left = (screen.width  - width)/2;
		var top = (screen.height - height)/2;
		var params = 'width='+width+', height='+height;
		params += ', top='+top+', left='+left;
		params += ', directories=no';
		params += ', location=no';
		params += ', resizable=no';
		params += ', status=no';
		params += ', toolbar=no';
		return params;
	}

	function openWin(url){
		myWindow=window.open(url,'mywin',param(800,500));
		myWindow.focus();
	}

	function openCustom(url,w,h){
		myWindow=window.open(url,'mywin',param(w,h));
		myWindow.focus();
	}
	
	function logout(){
		swal({
			title: "Logout",
			text: "Are you sure to Logout?",
			icon: "warning",
			buttons: true,
			dangerMode: true,
		})
		.then((willAdd) => {
			if (willAdd) {
				window.location.href = 'session_user/logoutstudent.php';
			} else {}
		});
	}	
	</script>
	
	</head>
	<body>
		<div class="wrapper d-flex align-items-stretch">
	<nav id="sidebar">
    <div class="custom-menu">
        <button type="button" id="sidebarCollapse" class="btn btn-warning">
            <i class="fa fa-bars"></i>
            <span class="sr-only">Toggle Menu</span>
        </button>
    </div>
    <div class="p-4 pt-5">
        <h1><a href="index.html" class="logo">  
			<img src="images/PUPLogo.png" alt="Your Image" style="width: 60px; height: 60px;">&nbsp;&nbsp;|
			CCIS</a></h1>

        <ul class="list-unstyled components mb-5">
            <li class="active">
                <a href="#"><i class="fa fa-dashboard"></i> Home</a>
            </li>
            <li>
                <a href="javascript:void();" onclick="loadPage('page_load/profile.php','content')"><i class="fa fa-user"></i> Profile</a>
            </li>
            <li>
                <a href="javascript:void();" onclick="loadPage('page_load/dashboard.php','content')"><i class="fa fa-building"></i> Dashboard</a>
            </li>
			 <li>
                <a href="javascript:void();" onclick="loadPage('page_load/company.php','content')"><i class="fa fa-industry"></i> Company</a>
            </li>
			<li>
                <a href="javascript:void();" onclick="logout()"><i class="fa fa-sign-out"></i> Logout</a>
            </li>
        </ul>
    </div>
</nav>
			
			<!-- Page Content  -->
		<div id="content" class="p-4 p-md-5 pt-5">
			<div class="content" style="height:100%;width:100%;"> 
				<div>
					<div class="headline">ENHANCE OJT WITH <br> OUR ADVANCED <br> MONITORING SYSTEM</div>
					<p>Polytechnic University's CCIS department leverages our state-of-the-art<br> OJT monitoring system to streamline and enhance the on-the-job training experience.</p>
					<button id="guideButton">OJT GUIDE</button>
				</div>
			</div>
		</div>
			
		</div>
		<script src="studentcss/js/jquery.min.js"></script>
		<script src="studentcss/js/popper.js"></script>
		<script src="studentcss/js/bootstrap.min.js"></script>
		<script src="studentcss/js/main.js"></script>
	</body>
</html>