<?php
	if (file_exists('includes/database.php')) { include_once('includes/database.php'); }
    if (file_exists('../includes/database.php')) { include_once('../includes/database.php'); }	
	
	$x = 1;
	
	if($x==1){
		echo $x;
	} else {
		echo 'darren';
	}

?>
