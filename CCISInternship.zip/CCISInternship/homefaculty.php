<?
session_start();
if (file_exists('includes/database.php')) { include_once('includes/database.php'); }
if (file_exists('../includes/database.php')) { include_once('../includes/database.php'); }


	$select = mysqli_query($db_connection, "SELECT * FROM tblfaculty WHERE facultyid = '$_SESSION[facultyid]'  ");
    $count = mysqli_num_rows($select);

    if($count == 0) {
      header("location:./");			
    }
?>


<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="icon" href="images/PUPLogo.png" type="image/ico">
	<title>Faculty | Panel</title>
	<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
	<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
	<link href="css/ruang-admin.min.css" rel="stylesheet">
	<script src="js/sweetalert.min.js"></script>
	<script src="js/tinybox.js"></script>
	<style>
		.tbox {position:absolute;  display:none; padding:14px 17px; z-index:900}
		.tinner {padding:15px; -moz-border-radius:5px; border-radius:5px; background:#fff url(images/preload.gif) no-repeat 50% 50%; border-right:1px solid #333; border-bottom:1px solid #333;}
		.tmask {position:absolute; display:none; top:0px; left:0px; height:100%; width:100%; background:#000; z-index:800}
		.tclose {position:absolute; top:0px; right:0px; width:30px; height:30px; cursor:pointer; background:url(images/close.png) no-repeat}
		.tclose:hover {background-position:0 -30px}
		
		#error {background:#ff6969; color:#fff; text-shadow:1px 1px #cf5454; border-right:1px solid #000; border-bottom:1px solid #000; padding:0}
		#error .tcontent {padding:10px 14px 11px; border:1px solid #ffb8b8; -moz-border-radius:5px; border-radius:5px}
		#success {background:#2ea125; color:#fff; text-shadow:1px 1px #1b6116; border-right:1px solid #000; border-bottom:1px solid #000; padding:10; -moz-border-radius:0; border-radius:0}
		#bluemask {background:#4195aa}
		#frameless {padding:0}
		#frameless .tclose {left:6px}
		
	.navbar{
		background-color:rgb(158, 30, 30);
	}
	.sidebar{
		background-color:rgb(128,0,0);
	}
	
	.sidebar-brand{
		background-color: rgb(128,0,0);
	}
	
	.sidebar-brand-text{
		color:rgb(255,236,117);
	}
	
	
	</style>
	<script>
    function loadSubContent(url,elementId) {
		if (window.XMLHttpRequest) {
				xmlhttp=new XMLHttpRequest();
		} else {
			xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		}   
		xmlhttp.onreadystatechange=function() {
			if (xmlhttp.readyState==4 && xmlhttp.status==200) {
				document.getElementById(elementId).innerHTML="";
				document.getElementById(elementId).innerHTML=xmlhttp.responseText;	
			}
		}  
		xmlhttp.open("GET",url,true);
		xmlhttp.send();	   
    }
	
	function loadPage(loc,eid) {
		document.getElementById(eid).innerHTML="<div align='center'><img src='images/loader.gif' width='35px' /></div>";
		loadSubContent(loc,eid);
	}
	
	function param(w,h) {
		var width  = w;
		var height = h;
		var left = (screen.width  - width)/2;
		var top = (screen.height - height)/2;
		var params = 'width='+width+', height='+height;
		params += ', top='+top+', left='+left;
		params += ', directories=no';
		params += ', location=no';
		params += ', resizable=no';
		params += ', status=no';
		params += ', toolbar=no';
		return params;
	}

	function openWin(url){
		myWindow=window.open(url,'mywin',param(800,500));
		myWindow.focus();
	}

	function openCustom(url,w,h){
		myWindow=window.open(url,'mywin',param(w,h));
		myWindow.focus();
	}
	
	function logout(){
		swal({
			title: "Logout",
			text: "Are you sure to Logout?",
			icon: "warning",
			buttons: true,
			dangerMode: true,
		})
		.then((willAdd) => {
			if (willAdd) {
				window.location.href = 'session_user/logoutemployee.php';
			} else {}
		});
	}	
	
	function object(id){return document.getElementById(id);}
	
	function updateinfo(){
	    var firstname = object('firstname').value;
	    var middlename = object('middlename').value;
	    var lastname = object('lastname').value;
	    var courseid = object('courseid').value;
	    var sectionid = object('sectionid').value;
		
		var picInput = document.getElementById('pic');
		var picFile = picInput.files[0];

		if (firstname !== '') {
		if (courseid != 0) {
		if (sectionid != 0) {
			let myForm = new FormData();
			myForm.append('firstname', firstname);
			myForm.append('middlename', middlename);
			myForm.append('lastname', lastname);
			myForm.append('courseid', courseid);
			myForm.append('sectionid', sectionid);
			myForm.append('pic', picFile);
		
			swal({
				title: "Basic Information",
				text: "Are you sure want to update your information?",
				icon: "info",
				buttons: true,
				dangerMode: true,
			})
			.then((willAdd) => {
				if (willAdd) {
					$.ajax({
						url: 'faculty/profile.php',
						type: "POST",
						data: myForm,
						beforeSend: function () {$("#body-overlay").show();},
						contentType: false,
						processData: false,
						success: function (data) {
							$("#maincontent").html(data);
							$("#maincontent").css('opacity', '1');
							$("#body-overlay").hide();
						   
							swal("Successfully Updated!", {
								icon: 'success',
								buttons: false,
								timer: 2000,
							});

						},
						error: function () {
							Swal.fire('Error', 'Error Processing Request', 'error');
						}
					});
				} else {}
			});		
		}else{swal('Error on Section','Please select section','error');}
		}else{swal('Error on Course','Please select course','error');}
		}else{swal('Error on First Name','Please input first name','error');}
	}
	
	function assign_president(studentid){
		
			swal({
				title: 'Assigning Class President',
				text: 'Are you sure you want to assign this student?',
				icon: "warning",
				buttons: true,
				dangerMode: true,
			})
			.then((willAdd) => {
				if (willAdd) {	

					swal("Successfully Updated!", {
								icon: 'success',
								buttons: false,
								timer: 2000,
							});
					x = 'faculty/classrep.php?studentid='+studentid;			
					loadPage(x,'maincontent');
				}
			});
	}
	
	function is_ojt_start(studentid){
		var studentname = object('studentname'+studentid).value;
			swal({
				title: 'On-the-job Training',
				text: 'Click OK if Mr./Ms. ' + studentname + '\'s OJT has started.',
				icon: "warning",
				buttons: true,
				dangerMode: true,
			})
			.then((willAdd) => {
				if (willAdd) {			
				x = 'faculty/classrep.php?get_ss='+studentid+'&ss='+studentid;			
					$.ajax({
						url: x, 
						type: "GET",
						beforeSend: function(){$("#body-overlay").show();},
						contentType: false,
						processData:false,
						success: function(data)
						{
						
						$("#maincontent").html(data);
						$("#maincontent").css('opacity','1');
							$("#body-overlay").hide();
							
						swal('Success','Successfully updated','success');
						},
						error: function() 
						{
							swal('Error','Error Processing Request ','error');
						} 	        
					});
				}
			});
	}
	
	//is_ojt_end
	function is_ojt_end(studentid){
		var studentname = object('studentname'+studentid).value;
			swal({
				title: 'On-the-job Training',
				text: 'Click OK if Mr./Ms. ' + studentname + '\'s OJT has ended.',
				icon: "warning",
				buttons: true,
				dangerMode: true,
			})
			.then((willAdd) => {
				if (willAdd) {			
				x = 'faculty/classrep.php?get_ending='+studentid;			
					$.ajax({
						url: x, 
						type: "GET",
						beforeSend: function(){$("#body-overlay").show();},
						contentType: false,
						processData:false,
						success: function(data)
						{
						
						$("#maincontent").html(data);
						$("#maincontent").css('opacity','1');
							$("#body-overlay").hide();
							
						swal('Success','Successfully updated','success');
						},
						error: function() 
						{
							swal('Error','Error Processing Request ','error');
						} 	        
					});
				}
			});
	}
	
	</script>
</head>

<body id="page-top">
  <div id="wrapper">
    <!-- Sidebar -->
    <ul class="navbar-nav sidebar sidebar accordion" id="accordionSidebar">
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="javascript:void();"
	  onclick="window.location.reload();">
        <div class="sidebar-brand-icon">
          <img src="images/PUPLogo.png">
        </div>
        <div class="sidebar-brand-text mx-3">Faculty</div>
      </a>
      <hr class="sidebar-divider my-0">
      <li class="nav-item active">
        <a class="nav-link" href="javascript:void();" onclick="window.location.reload();">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>
      <hr class="sidebar-divider">
      <div class="sidebar-heading">
        Menu
      </div>
	  
      <li class="nav-item">
        <a class="nav-link" href="javascript:void();"
		onclick="loadPage('faculty/studentlist.php','maincontent')">
          <i class="fas fa-fw fa-book"></i>
          <span>OJT List</span>
        </a>
      </li>
	 
	  <!--<li class="nav-item">
        <a class="nav-link" href="javascript:void();">
          <i class="fas fa-fw fa-clipboard"></i>
          <span>Student Task</span>
        </a>
      </li>-->
	  
	  
	  <li class="nav-item">
	  <a class="nav-link" href="javascript:void();" onclick="loadPage('faculty/classrep.php','maincontent')">
		 <i class="fas fa-fw fa-star"></i>
		<span>Student List</span>
	  </a>
	</li>
	  
	  
	  <hr class="sidebar-divider">
    </ul>
    <!-- Sidebar -->
    <div id="content-wrapper" class="d-flex flex-column">
      <div id="content">
        <!-- TopBar -->
        <nav class="navbar navbar-expand navbar-light bg-navbar topbar mb-4 static-top">
          <button id="sidebarToggleTop" class="btn btn-link rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>
          <ul class="navbar-nav ml-auto">
            <li hidden class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                aria-labelledby="searchDropdown">
                <form class="navbar-search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-1 small" placeholder="What do you want to look for?"
                      aria-label="Search" aria-describedby="basic-addon2" style="border-color: #3f51b5;">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="button">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>
            <li hidden class="nav-item dropdown no-arrow mx-1">
              <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-bell fa-fw"></i>
                <span class="badge badge-danger badge-counter">3+</span>
              </a>
              <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                aria-labelledby="alertsDropdown">
                <h6 class="dropdown-header">
                  Alerts Center
                </h6>
                <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="mr-3">
                    <div class="icon-circle bg-primary">
                      <i class="fas fa-file-alt text-white"></i>
                    </div>
                  </div>
                  <div>
                    <div class="small text-gray-500">December 12, 2019</div>
                    <span class="font-weight-bold">A new monthly report is ready to download!</span>
                  </div>
                </a>
                <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="mr-3">
                    <div class="icon-circle bg-success">
                      <i class="fas fa-donate text-white"></i>
                    </div>
                  </div>
                  <div>
                    <div class="small text-gray-500">December 7, 2019</div>
                    $290.29 has been deposited into your account!
                  </div>
                </a>
                <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="mr-3">
                    <div class="icon-circle bg-warning">
                      <i class="fas fa-exclamation-triangle text-white"></i>
                    </div>
                  </div>
                  <div>
                    <div class="small text-gray-500">December 2, 2019</div>
                    Spending Alert: We've noticed unusually high spending for your account.
                  </div>
                </a>
                <a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
              </div></li>

            <div class="topbar-divider d-none d-sm-block"></div>
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <img class="img-profile rounded-circle" src="img/boy.png" style="max-width: 60px">
                <span class="ml-2 d-none d-lg-inline text-white small"><?=FacultyName($_SESSION['facultyid'])?></span>
              </a>
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="javascript:void();"
				onclick="loadPage('faculty/profile.php','maincontent')">
                  <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                  Profile
                </a>
                <!--<a class="dropdown-item" href="#">
                  <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                  Settings
                </a>
                <a class="dropdown-item" href="#">
                  <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                  Activity Log
                </a>-->
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="javascript:void(0);" onclick="logout();">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>
          </ul>
        </nav>
        <!-- Topbar -->

        <!-- Container Fluid-->
        <div id="maincontent" class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Welcome Faculty Dashboard</h1>
			<!--<ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
            </ol>-->
          </div>

          <div class="row mb-3">
            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card h-100">
                <div class="card-body">
                  <div class="row align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">OJT Student Count</div>
                      <? $is_ojt = GetValue('SELECT COUNT(studentid) FROM tblstudent WHERE courseid='.
													$_SESSION['courseid'].' AND sectionid='.
													$_SESSION['sectionid'].' AND is_ojt=1'); ?>
													
					<? $is_ojt_no = GetValue('SELECT COUNT(studentid) FROM tblstudent WHERE courseid='.
													$_SESSION['courseid'].' AND sectionid='.
													$_SESSION['sectionid'].' AND is_ojt=0 AND is_end=0'); ?>
					<? $is_ojt_yes = GetValue('SELECT COUNT(studentid) FROM tblstudent WHERE courseid='.
													$_SESSION['courseid'].' AND sectionid='.
													$_SESSION['sectionid'].' AND is_ojt=1 AND is_end=1'); ?>
					  <div class="h5 mb-0 font-weight-bold text-gray-800"><?=$is_ojt?></div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <!--<span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 3.48%</span>
                        <span>Since last month</span>-->
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-graduation-cap fa-2x text-primary"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- Earnings (Annual) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card h-100">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">No OJT</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?=$is_ojt_no?></div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <!--<span class="text-success mr-2"><i class="fas fa-arrow-up"></i> 12%</span>
                        <span>Since last years</span>-->
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-user-slash fa-2x text-success"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
			
			<!-- Earnings (Annual) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card h-100">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">End OJT</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><?=$is_ojt_yes?></div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <!--<span class="text-success mr-2"><i class="fas fa-arrow-up"></i> 12%</span>
                        <span>Since last years</span>-->
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-flag-checkered fa-2x text-success"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- New User Card Example -->
            <!--<div class="col-xl-3 col-md-6 mb-4">
              <div class="card h-100">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">New User</div>
                      <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">366</div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-success mr-2"><i class="fas fa-arrow-up"></i> 20.4%</span>
                        <span>Since last month</span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-users fa-2x text-info"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- Pending Requests Card Example -->
            <!--<div class="col-xl-3 col-md-6 mb-4">
              <div class="card h-100">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Pending Requests</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">18</div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <span class="text-danger mr-2"><i class="fas fa-arrow-down"></i> 1.10%</span>
                        <span>Since yesterday</span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-comments fa-2x text-warning"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          
            <!-- Invoice Example -->
            <div class="col-xl-8 col-lg-7 mb-4">
              <div class="card">
              </div>
            </div>
			
          </div>
          <!--Row-->

          <!-- Modal Logout -->
          <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabelLogout"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabelLogout">Ohh No!</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                  <p>Are you sure you want to logout?</p>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-outline-primary" data-dismiss="modal">Cancel</button>
                  <a href="login.html" class="btn btn-primary">Logout</a>
                </div>
              </div>
            </div>
          </div>

        </div>
        <!---Container Fluid-->
      </div>
      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Group # 1
            </span>
          </div>
        </div>
      </footer>
      <!-- Footer -->
    </div>
  </div>

  <!-- Scroll to top -->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="js/ruang-admin.min.js"></script>
  <script src="vendor/chart.js/Chart.min.js"></script>
  <script src="js/demo/chart-area-demo.js"></script>  
</body>

</html>