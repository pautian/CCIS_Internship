<?php
if (file_exists('includes/database.php')) { include_once('includes/database.php'); }
if (file_exists('../includes/database.php')) { include_once('../includes/database.php'); }

$studentid = $_GET['studentid'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Accomplishment Photos</title>
    <style>
        body {
            font-family: 'Open Sans', sans-serif;
            background-color: #fff;
            color: #333;
            padding: 20px;
            text-align: center;
        }

        img {
            border-radius: 4px;
            margin: 10px 0;
            max-width: 100%;
            height: auto;
        }

        .description {
            margin: 10px 0;
            color: #555;
        }

        .photo-container {
            margin-bottom: 30px;
        }

        .photo-container h3 {
            color: #d32f2f;
            margin-bottom: 5px;
        }

        /* Add styles for larger screens */
        @media (min-width: 768px) {
            .photo-container {
                display: inline-block;
                vertical-align: top;
                margin: 10px;
                box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
                border: 1px solid #ddd;
                padding: 10px;
                background-color: #f9f9f9;
            }
        }
    </style>
</head>
<body>

<?php
$rs = mysqli_query($db_connection, 'SELECT picturedate, picture, description FROM tblaccomplishment_photo WHERE studentid=' . $studentid);
while ($rw = mysqli_fetch_array($rs)) {
    echo '<div class="photo-container">';
    echo '<h3>'.htmlspecialchars($rw['description'], ENT_QUOTES, 'UTF-8').'</h3>';
    echo '<img src="../page_load/pictures_entry/'.htmlspecialchars($rw['picture'], ENT_QUOTES, 'UTF-8').'" alt="Accomplishment Photo"/>';
    echo '</div>';
}
?>

</body>
</html>
