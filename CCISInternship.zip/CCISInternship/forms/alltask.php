<?php
session_start();
if (file_exists('includes/database.php')) { include_once('includes/database.php'); }
if (file_exists('../includes/database.php')) { include_once('../includes/database.php'); }

$studentid = $_GET['studentid'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Weekly Accomplishment Report</title>
    <style>
        body {
            font-family: 'Open Sans', sans-serif;
            background-color: #fff; /* Assuming the background is white */
            color: #333; /* Standard text color appears dark */
            margin: 0;
            padding: 20px;
        }

        h4 {
            color: #d32f2f; /* This red seems similar to the red in the image */
            text-align: center; /* Center the title if it fits the overall design */
        }

        table {
            width: 100%; /* Make the table full-width */
            border-collapse: collapse;
            margin-top: 20px; /* Add some space above the table */
        }

        th {
            background-color: #d32f2f; /* Header background color to match the theme */
            color: #fff; /* White text color for contrast */
            padding: 10px; /* Add some padding for a better look */
        }

        td {
            background-color: #ffffff; /* White background color for table cells */
            color: #333; /* Dark color for text for readability */
            padding: 10px; /* Padding for table cells */
            border: 1px solid #ddd; /* Light border for the table cells */
            text-align: center; /* Center text in cells */
        }

        a {
            color: #fff;
            background-color: #d32f2f; /* Button color to match the theme's red */
            padding: 5px 15px; /* Padding to make links look like buttons */
            text-decoration: none; /* No underline for links */
            border-radius: 4px; /* Rounded corners for buttons */
            transition: background-color 0.3s; /* Smooth transition for hover effect */
        }

        a:hover {
            background-color: #a52727; /* Darker shade of red for hover state */
        }
    </style>
</head>
<body>

<h4>Weekly Accomplishment Report</h4>

<?php
echo '<table>
        <tr>
            <th>Entry Report</th>
            <th>Days</th>
            <th>Status</th>
        </tr>';
        
        $rs2 = mysqli_query($db_connection, 'SELECT * FROM tblaccomplishmentreport WHERE studentid=' . $studentid);
        while ($rw2 = mysqli_fetch_array($rs2)) {
            echo '<tr>
                <td>' . $rw2['reportid'] . '</td>
                <td>' . date('M d, Y', strtotime($rw2['datefrom'])) . ' - ' . date('M d, Y', strtotime($rw2['dateto'])) . '</td>
                <td><a href="javascript:void()" onclick="openCustom(\'forms/task.php?reportid=' . $rw2['reportid'] . '\',900,900)">DONE</a></td>
                </tr>';
                $openme3 = 'openCustom(\'forms/task.php?reportid='.$rw2['reportid'].'\',900,900)';
        }
        
    echo '</table>';
?>
		   

</body>
</html>
