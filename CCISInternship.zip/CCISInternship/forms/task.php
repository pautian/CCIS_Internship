<?php
session_start();
if (file_exists('includes/database.php')) { include_once('includes/database.php'); }
if (file_exists('../includes/database.php')) { include_once('../includes/database.php'); }

$reportid = $_GET['reportid'];
$title = GetValue('SELECT title from tblaccomplishmentreport WHERE reportid='.$reportid);
$datefrom = GetValue('SELECT datefrom from tblaccomplishmentreport WHERE reportid='.$reportid);
$dateto = GetValue('SELECT dateto from tblaccomplishmentreport WHERE reportid='.$reportid);
$timein = GetValue('SELECT timein from tblaccomplishmentreport WHERE reportid='.$reportid);
$timeout = GetValue('SELECT timeout from tblaccomplishmentreport WHERE reportid='.$reportid);
$totalhours = GetValue('SELECT totalhours from tblaccomplishmentreport WHERE reportid='.$reportid);
$description = GetValue('SELECT description from tblaccomplishmentreport WHERE reportid='.$reportid);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Weekly Accomplishment Report</title>
    <style>
        body {
            font-family: 'Open Sans', sans-serif;
            background-color: #fff; /* Light background for the content */
            color: #333; /* Dark color for the text */
            max-width: 700px;
            margin: 20px auto;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1); /* Soft shadow for the content area */
        }

        h4 {
            color: #d32f2f; /* Red color to match the theme */
            margin-bottom: 1rem;
        }

        p, table {
            margin-top: 0.5rem;
            margin-bottom: 0.5rem;
            line-height: 1.6; /* Improved line-height for readability */
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid #ddd; /* Light border for the table cells */
            padding: 8px; /* Padding for table cells */
            text-align: left; /* Align text to the left */
        }

        th {
            background-color: #d32f2f; /* Red background for headers */
            color: #fff; /* White text for headers */
        }

        a {
            color: #d32f2f; /* Red color for the links to match the theme */
            text-decoration: none; /* Remove the underline from the links */
            padding: 5px 10px; /* Padding to make links appear as buttons */
            border: 1px solid #d32f2f; /* Border to match the theme color */
            border-radius: 4px; /* Rounded corners for the buttons */
            transition: background-color 0.2s, color 0.2s; /* Transition for hover effects */
        }

        a:hover {
            background-color: #d32f2f; /* Red background on hover */
            color: #fff; /* White text on hover */
        }

        .underline {
            text-decoration: underline;
            color: #d32f2f; /* Red color for the underlined text to match the theme */
        }

        .report-details {
            margin-bottom: 2rem;
        }
    </style>
</head>
<body>

<h4>Weekly Accomplishment Report</h4>

<div class="report-details">
    <p><strong>Title:</strong>&nbsp;<span class="underline"><?= htmlspecialchars($title) ?></span></p>
    <p><strong>Inclusive Dates:</strong>&nbsp;<span class="underline"><?= date('M d, Y', strtotime($datefrom)) ?> - <?= date('M d, Y', strtotime($dateto)) ?></span></p>
    <p><strong>Time In:</strong>&nbsp;<span class="underline"><?= htmlspecialchars($timein) ?></span><strong> Time Out:</strong>&nbsp;<span class="underline"><?= htmlspecialchars($timeout) ?></span></p>
    <p><strong>Total Hours:</strong>&nbsp;<span class="underline"><?= htmlspecialchars($totalhours) ?></span></p>
</div>





<p>Please classify activities as Systems Analysis and Design (SAD), Programming, System Maintenance, System Testing, IT Documentation and Research, Web Design, Networking, PC Troubleshooting, System Implementation, IT Training and Meeting, and other IT-related Activities.</p>

<table style="width:600px;">
	<tr>
		<td style="border-bottom:1px solid black;">&nbsp;<?=substr($description,0,130)?></td>
	</tr>
	<tr>
		<td style="border-bottom:1px solid black;">&nbsp;<?=substr($description,131,261)?></td>
	</tr>
	<tr>
		<td style="border-bottom:1px solid black;">&nbsp;<?=substr($description,262,392)?></td>
	</tr>
	<tr>
		<td style="border-bottom:1px solid black;">&nbsp;</td>
	</tr>
	<tr>
		<td style="border-bottom:1px solid black;">&nbsp;</td>
	</tr>
	<tr>
		<td style="border-bottom:1px solid black;">&nbsp;</td>
	</tr>
	<tr>
		<td style="border-bottom:1px solid black;">&nbsp;</td>
	</tr>
	<tr>
		<td style="border-bottom:1px solid black;">&nbsp;</td>
	</tr>
	<tr>
		<td style="border-bottom:1px solid black;">&nbsp;</td>
	</tr>
	<tr>
		<td style="border-bottom:1px solid black;">&nbsp;</td>
	</tr>
	<tr>
		<td style="border-bottom:1px solid black;">&nbsp;</td>
	</tr>
	<tr>
		<td style="border-bottom:1px solid black;">&nbsp;</td>
	</tr>
	<tr>
		<td style="border-bottom:1px solid black;">&nbsp;</td>
	</tr>
	
</table>


</body>
</html>