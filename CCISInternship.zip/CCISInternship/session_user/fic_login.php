<?

if (file_exists('includes/database.php')) { include_once('includes/database.php'); }
if (file_exists('../includes/database.php')) { include_once('../includes/database.php'); }


?>
<? if($err){echo $err;} ?>
	<form method="post">
		<div class="title">PUP OJT</div>
        <div class="subtext">Sign in to start your session</div>
        <input type="text" name="username" placeholder="USER NAME" class="textbox">
        <input type="password" name="password" placeholder="PASSWORD" class="textbox">
        <input type="submit" name="sign_faculty" class="button" value="SIGN IN"/>
        <div class="forgot"><a style="text-decoration:none;color:red;" href="forgot/forgotpassword_faculty.php">I forgot my password</a></div>
	</form>
