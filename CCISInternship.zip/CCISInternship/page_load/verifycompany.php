<?php
session_start();
if (file_exists('includes/database.php')) { include_once('includes/database.php'); }
if (file_exists('../includes/database.php')) { include_once('../includes/database.php'); }

	
	
if(isset($_GET['idnum'])){
	$companyid = $_GET['companyid'];
	$courseid = $_GET['courseid'];
	$sectionid = $_GET['sectionid'];
	
	//mysqli_query($db_connection,'UPDATE tblapplication_tmp SET is_selected=1 WHERE idnum='.$_GET['idnum']);
	mysqli_query($db_connection,'UPDATE tblapplication_tmp SET is_reject=1 WHERE studentid='.
																$_SESSION['studentid'].' AND courseid='.
																$courseid.' AND sectionid='.
																$sectionid.' ');
	mysqli_query($db_connection,'UPDATE tblapplication_tmp SET is_selected=1, is_reject=0 WHERE idnum='.$_GET['idnum']);
	
	//Here insert to tblapplication && tblcompany_ojt && update tblstudent
	mysqli_query($db_connection,'INSERT INTO tblapplication SET applicationdatetime=NOW(),
													studentid='.
										$_SESSION['studentid'].',companyid='.
										$companyid.',status=1  ');
	mysqli_query($db_connection,'INSERT INTO tblcompany_ojt SET studentid='.
										$_SESSION['studentid'].',companyid='.
										$companyid.',is_endorse=1,courseid='.
										$courseid.',sectionid='.
										$sectionid.'  ');
	mysqli_query($db_connection,'UPDATE tblstudent SET is_endorse=1,companyid='.$companyid.' WHERE studentid='.
										$_SESSION['studentid']);
	
	$applicants = GetValue('SELECT applicants FROM tblsection WHERE courseid='.$courseid.'
											AND sectionid='.$sectionid.' ') + 1;
	mysqli_query($db_connection,'UPDATE tblsection SET applicants='.$applicants.' WHERE sectionid='.$sectionid);
										
	
	
}


if(isset($_GET['reject'])){
	mysqli_query($db_connection,'UPDATE tblapplication_tmp SET is_reject=1 WHERE idnum='.$_GET['reject']);
}
?>
<style>
   
   
    a {
        text-decoration: none;
        color: #007bff;
        cursor: pointer;
    }

    /* Table styling */
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    th, td {
        border: 1px solid #dddddd;
        text-align: left;
        padding: 8px;
    }

    th {
        background-color: #f2f2f2;
    }

    /* Additional styling for links within the table */
    td a {
        color: #007bff;
    }

    /* Container for each table */
    .table-container {
        display: inline-block;
        width: 45%;
        float: left;
        margin-right: 5%;
    }

    /* Optional: Add styling for the "VIEW ALL" row */
    td[onclick] {
        cursor: pointer;
        background-color: rgb(128,0,0);
        color: #ffffff;
        font-weight: bold;
    }
</style>
<?php

	$link = "TINY.box.show({url:'page_load/addpictures.php?studentid=".$_SESSION['studentid']."',width:400,height:80 })";
	$link2 = "TINY.box.show({url:'page_load/addreport.php?studentid=".$_SESSION['studentid']."',width:800,height:450 })";
    echo '<div style="margin-left:150px;margin-top:60px;">
            <h5><a href="javsacript:void();"
			>Choose company where you accepted to</a><h5><br><br><br>';
	
 

    echo '<div style="display:inline-block; width: 45%; float: left;">';
    echo '<h5>Companies Apply</h5>';
    echo '<table border="1" style="border-collapse:collapse;">
            <tr>
                <th>Company</th>
                <th>REJECT</th>
                <th>&nbsp;</th>
            </tr>';
            
			$rs2 = mysqli_query($db_connection,'SELECT * FROM tblapplication_tmp WHERE studentid='.$_SESSION['studentid'].' AND is_endorse=1 AND sectionid='.$_SESSION['sectionid'].' AND courseid='.$_SESSION['courseid'].'');
			while($rw2 = mysqli_fetch_array($rs2)){
				echo'<tr>
					<td>'.CompanyName($rw2['companyid']).'</td>';
					
					if($rw2['is_reject']==1){
						echo'<td>Rejected</td>';
						echo'<td>Rejected</td>';
						
					}
					
					if($rw2['is_reject']==0 && $rw2['is_selected']==0){
						echo'<td><a style="color:red;" href="javacsript:void(0)" onclick="reject_company('.$rw2['idnum'].');">REJECT</a></td>';
					
						echo'<td><a href="javacsript:void(0)" 
						onclick="accept_company('.$rw2['idnum'].','.$rw2['companyid'].',
								'.$rw2['courseid'].','.$rw2['sectionid'].');">ACCEPT</a></td>';
					
					}
					
					if($rw2['is_selected']==1){
						echo'<td><span style="color:green;">ACCEPTED</span></td>';
						echo'<td><span style="color:green;">ACCEPTED</span></td>';
					
					}
				echo'</tr>';
			}
			
        echo'</table>';
    echo '</div>';

    echo '</div>';

?>
