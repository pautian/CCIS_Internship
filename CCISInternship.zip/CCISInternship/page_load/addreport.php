<?
session_start();
if (file_exists('includes/database.php')) { include_once('includes/database.php'); }
if (file_exists('../includes/database.php')) { include_once('../includes/database.php'); }

$is_ojt = GetValue('SELECT is_ojt FROM tblstudent WHERE studentid='.$_SESSION['studentid']);
	
?>

<style>
        

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            margin-bottom: 8px;
            font-weight: bold;
        }

        input {
            width: 38%;
            padding: 8px;
            margin-bottom: 16px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
            background-color: #4caf50;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
			margin-left:auto;
        }

        button:hover {
            background-color: #45a049;
        }
		
		textarea{width:100%;}
    </style>
<?
echo'
	<h4>Weekly Accomplishment Report&nbsp;&nbsp;<input type="text" placeholder="input Title of weekly report" id="title" name="title" required></h4>
    <form>
        <label for="dateFrom">Date From:</label>
        <input type="date" id="datefrom" name="datefrom" required>

        <label for="dateTo">Date To:</label>
        <input type="date" id="dateto" name="dateto" required>

        <label for="timeIn">Time In:</label>
        <input type="time" id="timein" name="timein" required>

        <label for="timeOut">Time Out:</label>
        <input type="time" id="timeout" name="timeout" required>

        <label for="totalHours">Total No. of Hours:</label>
        <input type="number" id="totalhours" name="totalhours">
<br>
        <label for="description">Description:</label>
        <textarea  id="description" name="description" style="height:100px;" required></textarea>
        </form><button type="submit" onclick="submit_weekly()">Submit</button>';
		
		
?>