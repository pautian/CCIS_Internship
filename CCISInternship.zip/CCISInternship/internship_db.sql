-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 28, 2023 at 03:17 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `internship_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblaccomplishmentreport`
--

CREATE TABLE `tblaccomplishmentreport` (
  `reportid` int(11) NOT NULL,
  `studentid` int(11) DEFAULT 0,
  `title` varchar(128) DEFAULT '',
  `datefrom` date DEFAULT NULL,
  `dateto` date DEFAULT NULL,
  `timein` time DEFAULT NULL,
  `timeout` time DEFAULT NULL,
  `totalhours` int(11) DEFAULT NULL,
  `description` varchar(500) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblaccomplishmentreport`
--

INSERT INTO `tblaccomplishmentreport` (`reportid`, `studentid`, `title`, `datefrom`, `dateto`, `timein`, `timeout`, `totalhours`, `description`) VALUES
(1, 5, '', '0000-00-00', '0000-00-00', '00:00:00', '00:00:00', 0, 'kjsdjk');

-- --------------------------------------------------------

--
-- Table structure for table `tblaccomplishment_photo`
--

CREATE TABLE `tblaccomplishment_photo` (
  `idnum` int(11) NOT NULL,
  `studentid` int(11) DEFAULT 0,
  `picture` varchar(256) DEFAULT '',
  `picturedate` datetime DEFAULT NULL,
  `description` varchar(256) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblapplication`
--

CREATE TABLE `tblapplication` (
  `applicationid` int(11) NOT NULL,
  `applicationdatetime` datetime DEFAULT NULL,
  `studentid` int(11) DEFAULT 0,
  `companyid` int(11) DEFAULT 0,
  `status` tinyint(1) DEFAULT 0,
  `is_reject` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblapplication`
--

INSERT INTO `tblapplication` (`applicationid`, `applicationdatetime`, `studentid`, `companyid`, `status`, `is_reject`) VALUES
(1, '2023-11-27 18:01:34', 2, 1, 1, 0),
(2, '2023-11-27 22:08:48', 5, 3, 1, 0),
(3, '2023-11-28 19:23:28', 1, 9, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblapplication_tmp`
--

CREATE TABLE `tblapplication_tmp` (
  `idnum` int(11) NOT NULL,
  `studentid` int(11) DEFAULT 0,
  `courseid` int(11) DEFAULT 0,
  `sectionid` int(11) DEFAULT 0,
  `companyid` int(11) DEFAULT 0,
  `applicationdate` datetime DEFAULT NULL,
  `is_endorse` tinyint(1) DEFAULT 0,
  `is_reject` tinyint(1) DEFAULT 0,
  `is_selected` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblapplication_tmp`
--

INSERT INTO `tblapplication_tmp` (`idnum`, `studentid`, `courseid`, `sectionid`, `companyid`, `applicationdate`, `is_endorse`, `is_reject`, `is_selected`) VALUES
(4, 2, 1, 3, 7, '2023-11-27 15:57:45', 0, 1, 0),
(5, 2, 1, 3, 1, '2023-11-27 15:57:50', 1, 0, 1),
(6, 2, 1, 3, 3, '2023-11-27 15:57:55', 1, 1, 0),
(7, 3, 1, 3, 1, '2023-11-27 16:05:59', 1, 0, 0),
(8, 3, 1, 3, 8, '2023-11-27 16:06:07', 1, 0, 0),
(9, 3, 1, 3, 4, '2023-11-27 16:06:12', 1, 0, 0),
(10, 4, 1, 3, 5, '2023-11-27 16:13:38', 1, 0, 0),
(11, 4, 1, 3, 1, '2023-11-27 16:13:42', 1, 0, 0),
(12, 4, 1, 3, 2, '2023-11-27 16:13:46', 1, 0, 0),
(13, 1, 1, 3, 2, '2023-11-27 17:35:03', 1, 1, 0),
(14, 1, 1, 3, 9, '2023-11-27 17:35:07', 1, 0, 1),
(15, 1, 1, 3, 1, '2023-11-27 17:35:11', 1, 1, 0),
(16, 5, 1, 1, 7, '2023-11-27 18:16:57', 0, 1, 0),
(17, 5, 1, 1, 1, '2023-11-27 18:17:00', 1, 1, 0),
(18, 5, 1, 1, 3, '2023-11-27 18:17:02', 1, 0, 1),
(19, 6, 1, 6, 1, '2023-11-27 23:05:23', 0, 0, 0),
(20, 6, 1, 6, 2, '2023-11-27 23:05:27', 0, 0, 0),
(21, 6, 1, 6, 4, '2023-11-27 23:05:31', 0, 0, 0),
(22, 7, 1, 1, 6, '2023-11-28 00:04:44', 0, 0, 0),
(23, 7, 1, 1, 7, '2023-11-28 00:04:49', 0, 0, 0),
(24, 7, 1, 1, 10, '2023-11-28 00:04:54', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblcompany`
--

CREATE TABLE `tblcompany` (
  `companyid` int(11) NOT NULL,
  `companycode` varchar(128) DEFAULT '',
  `companyname` varchar(256) DEFAULT '',
  `signatory` varchar(128) DEFAULT '',
  `position` varchar(256) DEFAULT '',
  `address` longtext DEFAULT NULL,
  `notarizationdate` date DEFAULT NULL,
  `max_apply` int(11) DEFAULT 0,
  `applicants` int(11) DEFAULT 0,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `notify_date` date DEFAULT NULL,
  `moa_img` varchar(255) DEFAULT '',
  `company_link` varchar(400) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcompany`
--

INSERT INTO `tblcompany` (`companyid`, `companycode`, `companyname`, `signatory`, `position`, `address`, `notarizationdate`, `max_apply`, `applicants`, `start_date`, `end_date`, `notify_date`, `moa_img`, `company_link`) VALUES
(1, '', 'LIBERTY INSURANCE CORP.', 'MELISSA T. MILCA', 'SENIOR MANAGER FOR HUMAN RESOURCES AND ADMINISTRATION', 'JCS Building No. 119 Dela Rosa cor. C. Palanca Sts. Legaspi Village Makati City', '2023-04-14', 0, 0, '2023-11-21', '2023-12-21', '2023-11-21', '', 'https://www.google.com/'),
(2, '', 'FASTSEND MOBILE SOLUTIONS CORPORATION', 'ROBERT MICHAEL P. CRESPO', 'CEO', 'Unit 7E PDCP Bankc Centre V.A. Rufino St. Salcedo Village Bel-Air City of Makati', '2023-04-14', 100, 0, '2023-11-21', '2023-12-21', '2023-11-21', '', ''),
(3, '', 'SHORETEL PHILIPPINES CORP.', 'JOHN EARVIN V. FLORES', 'TERRITORY ACCOUNT MANAGER', '12th Floor Multinational Bancorporation Centre 6805 Ayala Ave. Makati City', '2023-04-14', 0, 0, '2023-11-21', '2023-12-21', '2023-11-21', '', ''),
(4, '', 'DEVXPRESS IT SOLUTIONS', 'FRANCIS S. MANAIG', 'OWNER', 'Calamba City Laguna', '2023-04-14', 0, 0, '2023-11-21', '2024-01-21', '2023-12-21', '', ''),
(5, '', 'DYIPPAY REVOLUTION CORPORATION', 'ENRIQUE TAN ', 'CEO', 'Baras TBI Bulacan State University Malolos Bulacan', '2023-04-14', 0, 0, '2023-11-21', '2023-12-21', '2023-11-21', '', ''),
(6, '', 'DAHUA TECHNOLOGY (HK) LIMITED (PHILIPPINE REPRESENTATIVE OFFICE)', 'DIANNE ALYSSA F. CARDINO', 'HR & ADMIN MANAGER', 'Unit 1919 One Park Drive cor. 9th Ave. Taguig Metro Manila', '2023-05-04', 0, 0, '2023-09-21', '2025-12-20', '2025-11-20', '', ''),
(7, '', 'PHILIPPINE AIR FORCE', '1LT. HERBERT MARK T. MADURO PAF', 'DIRECTOR FOR CMO', 'Col. Jesus Villamor Air Base', '2023-05-04', 0, 0, '2023-11-21', '2023-12-21', '2023-11-21', '', ''),
(8, '', 'ECO GLOBAL CONSULTING INC.', 'ELENITA C. DELA ROSA', 'FOUNDER & CEO', '20th Floor Zuellig Building Makati Ave. cor Paseo De Roxas Makati City', '2023-05-04', 0, 0, '2023-11-21', '2023-12-21', '2023-11-21', '', ''),
(9, '', 'BARKERO IT CONSULTANCY ', 'VINCENT MARTIN NICDAO HERMOSURA', 'CEO', '1129 Angel Linao Street cor Pres. Quirino Ave. Manila', '2023-05-18', 0, 0, '2022-11-01', '2023-12-01', '2023-11-01', '', ''),
(10, '', 'TAOCROWD INC.', 'BERNICE BUENAFE', 'COMPANY REPRESENTAIVE', 'Unit 707 One Park Drive 11th Drive cor. 95h Ave. Bonifacio Global City, Fort Bonifacio, Taguig City', '2020-05-18', 0, 0, '2023-11-21', '2023-12-21', '2023-11-21', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tblcompany_ojt`
--

CREATE TABLE `tblcompany_ojt` (
  `idnum` int(11) NOT NULL,
  `companyid` int(11) DEFAULT 0,
  `studentid` int(11) DEFAULT 0,
  `courseid` int(11) DEFAULT 0,
  `sectionid` int(11) DEFAULT 0,
  `is_endorse` int(1) DEFAULT 0,
  `is_ojt` tinyint(1) DEFAULT 0,
  `is_end` tinyint(1) DEFAULT 0,
  `is_cancel` tinyint(1) DEFAULT 0,
  `start_intern` datetime DEFAULT NULL,
  `end_intern` datetime DEFAULT NULL,
  `is_complete` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcompany_ojt`
--

INSERT INTO `tblcompany_ojt` (`idnum`, `companyid`, `studentid`, `courseid`, `sectionid`, `is_endorse`, `is_ojt`, `is_end`, `is_cancel`, `start_intern`, `end_intern`, `is_complete`) VALUES
(1, 1, 2, 1, 3, 1, 1, 1, 0, '2023-11-27 18:02:58', '2023-11-27 18:10:05', 0),
(2, 3, 5, 1, 1, 1, 1, 0, 0, '2023-11-27 22:09:42', NULL, 0),
(3, 9, 1, 1, 3, 1, 1, 0, 0, '2023-11-28 19:24:06', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblcourse`
--

CREATE TABLE `tblcourse` (
  `courseid` int(11) NOT NULL,
  `coursecode` varchar(128) DEFAULT '',
  `coursename` varchar(256) DEFAULT '',
  `departmentid` int(11) DEFAULT NULL,
  `max_apply` int(11) DEFAULT 0,
  `applicants` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcourse`
--

INSERT INTO `tblcourse` (`courseid`, `coursecode`, `coursename`, `departmentid`, `max_apply`, `applicants`) VALUES
(1, 'BSIT', 'Bachelor of Science in Information Technology', 1, 100, 0),
(2, 'BSCS', 'Bachelor of Science in Computer Science', 1, 100, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbldepartment`
--

CREATE TABLE `tbldepartment` (
  `departmentid` int(11) NOT NULL,
  `departmentcode` varchar(128) DEFAULT '',
  `departmentname` varchar(256) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbldepartment`
--

INSERT INTO `tbldepartment` (`departmentid`, `departmentcode`, `departmentname`) VALUES
(1, 'CCIS', 'College of Computer and Information Sciences');

-- --------------------------------------------------------

--
-- Table structure for table `tblendorsement`
--

CREATE TABLE `tblendorsement` (
  `endorsementid` int(11) NOT NULL,
  `courseid` int(11) DEFAULT 0,
  `sectionid` int(11) DEFAULT 0,
  `companyid` int(11) DEFAULT 0,
  `is_selected` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblfaculty`
--

CREATE TABLE `tblfaculty` (
  `facultyid` int(11) NOT NULL,
  `firstname` varchar(128) DEFAULT '',
  `middlename` varchar(128) DEFAULT '',
  `lastname` varchar(128) DEFAULT '',
  `username` varchar(128) DEFAULT '',
  `email` varchar(128) DEFAULT '',
  `password` varchar(128) DEFAULT '',
  `sectionid` int(11) DEFAULT 0,
  `departmentid` int(11) DEFAULT 0,
  `courseid` int(11) DEFAULT 0,
  `usertype` int(11) DEFAULT 0,
  `imagefaculty` varchar(256) DEFAULT '',
  `is_approve` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblfaculty`
--

INSERT INTO `tblfaculty` (`facultyid`, `firstname`, `middlename`, `lastname`, `username`, `email`, `password`, `sectionid`, `departmentid`, `courseid`, `usertype`, `imagefaculty`, `is_approve`) VALUES
(1, 'Coordinator', '', 'Coordinator', 'coordinator', 'evangelistabeah3@gmail.com', '1b207465eac83b5d4b12e335faa0b53a', 0, 0, 1, 1, '', 0),
(2, 'Teacher 4-1', '', '--', 'Teacher 4-1', 'evangelistabeah3@gmail.com', '1b207465eac83b5d4b12e335faa0b53a', 1, 0, 1, 0, '', 0),
(3, 'Teacher 4-2', '', 'LastnamePaula', 'Teacher 4-2', 'evangelistabeah3@gmail.com', '1b207465eac83b5d4b12e335faa0b53a', 2, 0, 1, 0, '', 0),
(4, 'Teacher 4-3', '', 'LastnamePaula', 'Teacher 4-3', 'evangelistabeah3@gmail.com', '1b207465eac83b5d4b12e335faa0b53a', 3, 0, 1, 0, '', 0),
(5, 'Teacher 4-4', '', 'LastnamePaula', 'Teacher 4-4', 'evangelistabeah3@gmail.com', '1b207465eac83b5d4b12e335faa0b53a', 4, 0, 1, 0, '', 0),
(6, 'Teacher 4-5', '', 'LastnamePaula', 'Teacher 4-5', 'evangelistabeah3@gmail.com', '1b207465eac83b5d4b12e335faa0b53a', 5, 0, 1, 0, '', 0),
(7, 'Teacher 4-1N', '', 'LastnamePaula', 'Teacher 4-1N', 'evangelistabeah3@gmail.com', '1b207465eac83b5d4b12e335faa0b53a', 6, 0, 1, 0, '', 0),
(8, 'Teacher 4-2N', '', 'LastnamePaula', 'Teacher 4-2N', 'evangelistabeah3@gmail.com', '1b207465eac83b5d4b12e335faa0b53a', 7, 0, 1, 0, '', 0),
(9, 'Teacher 3-1', '', 'LastnamePaula', 'Teacher 3-1', 'evangelistabeah3@gmail.com', '1b207465eac83b5d4b12e335faa0b53a', 8, 0, 2, 0, '', 0),
(10, 'Teacher 3-2', '', 'LastnamePaula', 'Teacher 3-2', 'evangelistabeah3@gmail.com', '1b207465eac83b5d4b12e335faa0b53a', 9, 0, 2, 0, '', 0),
(11, 'Teacher 3-3', '', 'LastnamePaula', 'Teacher 3-3', 'evangelistabeah3@gmail.com', '1b207465eac83b5d4b12e335faa0b53a', 10, 0, 2, 0, '', 0),
(12, 'Teacher 3-4', '', 'LastnamePaula', 'Teacher 3-4', 'evangelistabeah3@gmail.com', '1b207465eac83b5d4b12e335faa0b53a', 11, 0, 2, 0, '', 0),
(13, 'Teacher 3-5', '', 'LastnamePaula', 'Teacher 3-5', 'evangelistabeah3@gmail.com', '1b207465eac83b5d4b12e335faa0b53a', 12, 0, 2, 0, '', 0),
(14, 'Teacher 3-1N', '', 'LastnamePaula', 'Teacher 3-1N', 'evangelistabeah3@gmail.com', '1b207465eac83b5d4b12e335faa0b53a', 13, 0, 2, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblinterntype`
--

CREATE TABLE `tblinterntype` (
  `typeid` int(11) DEFAULT NULL,
  `type` varchar(128) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblinterntype`
--

INSERT INTO `tblinterntype` (`typeid`, `type`) VALUES
(1, 'On-site Internship'),
(2, 'Online Internship'),
(3, 'Hybrid Internship');

-- --------------------------------------------------------

--
-- Table structure for table `tblrating`
--

CREATE TABLE `tblrating` (
  `ratingid` int(11) NOT NULL,
  `description` varchar(256) DEFAULT '',
  `studentid` int(11) DEFAULT 0,
  `companyid` int(11) DEFAULT 0,
  `datetime_rate` datetime DEFAULT NULL,
  `rating` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblrating`
--

INSERT INTO `tblrating` (`ratingid`, `description`, `studentid`, `companyid`, `datetime_rate`, `rating`) VALUES
(1, 'Random Rating', 1, 6, '2023-11-27 17:48:38', 3),
(2, 'Random Rating', 1, 7, '2023-11-27 17:48:38', 5),
(3, 'Random Rating', 1, 8, '2023-11-27 17:48:38', 3),
(4, 'Random Rating', 1, 9, '2023-11-27 17:48:38', 2),
(5, 'Random Rating', 1, 10, '2023-11-27 17:48:38', 1),
(6, 'Galing', 2, 1, '2023-11-27 18:10:43', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblreset`
--

CREATE TABLE `tblreset` (
  `resetid` int(11) NOT NULL,
  `studentid` int(11) DEFAULT 0,
  `token` varchar(128) DEFAULT '',
  `is_inactive` tinyint(1) DEFAULT 0,
  `time_now` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblreset`
--

INSERT INTO `tblreset` (`resetid`, `studentid`, `token`, `is_inactive`, `time_now`) VALUES
(1, 2, '64955', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblreset_f`
--

CREATE TABLE `tblreset_f` (
  `resetid` int(11) NOT NULL,
  `facultyid` int(11) DEFAULT 0,
  `token` varchar(128) DEFAULT '',
  `is_inactive` tinyint(1) DEFAULT 0,
  `time_now` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblsection`
--

CREATE TABLE `tblsection` (
  `sectionid` int(11) NOT NULL,
  `sectioncode` varchar(128) DEFAULT '',
  `courseid` int(11) DEFAULT 0,
  `max_apply` int(11) DEFAULT 40,
  `max_slots` int(11) DEFAULT 7,
  `applicants` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsection`
--

INSERT INTO `tblsection` (`sectionid`, `sectioncode`, `courseid`, `max_apply`, `max_slots`, `applicants`) VALUES
(1, '4-1', 1, 40, 7, 1),
(2, '4-2', 1, 40, 7, 0),
(3, '4-3', 1, 40, 7, 2),
(4, '4-4', 1, 40, 7, 0),
(5, '4-5', 1, 40, 7, 0),
(6, '4-1N', 1, 40, 7, 0),
(7, '4-2N', 1, 40, 7, 0),
(8, '3-1', 2, 40, 7, 0),
(9, '3-2', 2, 40, 7, 0),
(10, '3-3', 2, 40, 7, 0),
(11, '3-4', 2, 40, 7, 0),
(12, '3-5', 2, 40, 7, 0),
(13, '3-1N', 2, 40, 7, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblstudent`
--

CREATE TABLE `tblstudent` (
  `studentid` int(11) NOT NULL,
  `studentno` varchar(128) DEFAULT '',
  `dateofbirth` date DEFAULT NULL,
  `typeid` tinyint(1) DEFAULT 0,
  `resume` varchar(256) DEFAULT '',
  `cv` varchar(256) DEFAULT '',
  `bio` longtext DEFAULT NULL,
  `skills` longtext DEFAULT NULL,
  `other_info` longtext DEFAULT NULL,
  `consent` varchar(256) DEFAULT '',
  `profilepic` varchar(256) DEFAULT '',
  `firstname` varchar(128) DEFAULT '',
  `middleinitial` char(10) DEFAULT '',
  `middlename` varchar(128) DEFAULT '',
  `lastname` varchar(128) DEFAULT '',
  `gender` char(1) DEFAULT '',
  `email` varchar(128) DEFAULT '',
  `contactno` varchar(128) DEFAULT '',
  `address` varchar(256) DEFAULT '',
  `studentpassword` varchar(128) DEFAULT '',
  `is_president` tinyint(1) DEFAULT 0,
  `departmentid` int(11) DEFAULT 0,
  `courseid` int(11) DEFAULT 0,
  `sectionid` int(11) DEFAULT 0,
  `companyid` int(11) DEFAULT 0,
  `facultyid` int(11) DEFAULT 0,
  `is_endorse` tinyint(1) DEFAULT 0,
  `is_ojt` tinyint(1) DEFAULT 0,
  `is_end` tinyint(1) DEFAULT 0,
  `is_updated` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblstudent`
--

INSERT INTO `tblstudent` (`studentid`, `studentno`, `dateofbirth`, `typeid`, `resume`, `cv`, `bio`, `skills`, `other_info`, `consent`, `profilepic`, `firstname`, `middleinitial`, `middlename`, `lastname`, `gender`, `email`, `contactno`, `address`, `studentpassword`, `is_president`, `departmentid`, `courseid`, `sectionid`, `companyid`, `facultyid`, `is_endorse`, `is_ojt`, `is_end`, `is_updated`) VALUES
(1, '2020-01437-MN-0', '2002-06-15', 1, 'MED.png', 'Minimalist (2).png', 'never give up', NULL, NULL, 'Minimalist (2).png', 'me.jpg', 'Paula', '', '', 'Evangelista', 'F', 'evangelistabeah3@gmail.com', '09064669085', '017 zone 1Santo Domingo', '1b207465eac83b5d4b12e335faa0b53a', 0, 0, 1, 3, 9, 0, 1, 1, 0, 1),
(2, '2020-01925-MN-0', '2023-01-01', 3, 'MED.png', 'Minimalist (2)(1).png', 'ehehehe', 'GREAT AT EVERYTHING\n', 'THE BEST INTERN CANDIDATE EVER', 'CONSENT.png', 'JHANNEX.png', 'Anthony', '', '', 'Olasiman', 'M', 'jhannexolaco88@gmail.com', '09999999999', 'Rizal', '1b207465eac83b5d4b12e335faa0b53a', 0, 0, 1, 3, 1, 0, 1, 1, 1, 1),
(3, '2020-09990-MN-0', '2002-03-27', 3, 'MED.png', 'Minimalist.png', 'ayoko na magcapstone', 'good typing skills', 'Great at backend coding', 'CONSENT.png', 'owen.png', 'Owen Alexis', '', '', 'Anicas', 'M', 'owenelexis0327@gmail.com', '09215545074', 'Pasig City', '1b207465eac83b5d4b12e335faa0b53a', 1, 0, 1, 3, 0, 0, 0, 0, 0, 1),
(4, '2020-01438-MN-0', '2001-09-29', 0, 'MED.png', 'Minimalist (3).png', 'I luv mark', NULL, NULL, 'CONSENT.png', 'TINE.png', 'Kristine', '', '', 'Castillo', 'F', 'castillokristine29@gmail.com', '09499684712', 'Montalban, Rizal', '1b207465eac83b5d4b12e335faa0b53a', 0, 0, 1, 3, 0, 0, 0, 0, 0, 1),
(6, '2020-01439-MN-0', '2002-06-02', 1, 'MED.png', 'Minimalist (2)(1).png', 'lelelele', 'BEST IN TYPING', 'GREAT FRIEND', 'CONSENT.png', 'MIGS.png', 'Lorenzo', '', '', 'Boyles', 'M', 'miguelboyles01@gmail.com', '0999999123', 'Antipolo Rizal', '1b207465eac83b5d4b12e335faa0b53a', 0, 0, 1, 1, 0, 0, 0, 0, 0, 1),
(7, '2020-01440-MN-0', '2001-01-01', 0, 'MED.png', 'Minimalist (3).png', 'I luv migz', 'magaling mamaril', 'Best streamer ever', 'CONSENT.png', 'LELHY.png', 'Alelhy', '', '', 'Sison', 'F', 'alehlysison@gmail.com', '09283u2i8', 'Bacoor Cavite', '1b207465eac83b5d4b12e335faa0b53a', 0, 0, 1, 1, 0, 0, 0, 0, 0, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblaccomplishmentreport`
--
ALTER TABLE `tblaccomplishmentreport`
  ADD PRIMARY KEY (`reportid`);

--
-- Indexes for table `tblaccomplishment_photo`
--
ALTER TABLE `tblaccomplishment_photo`
  ADD PRIMARY KEY (`idnum`);

--
-- Indexes for table `tblapplication`
--
ALTER TABLE `tblapplication`
  ADD PRIMARY KEY (`applicationid`);

--
-- Indexes for table `tblapplication_tmp`
--
ALTER TABLE `tblapplication_tmp`
  ADD PRIMARY KEY (`idnum`);

--
-- Indexes for table `tblcompany`
--
ALTER TABLE `tblcompany`
  ADD PRIMARY KEY (`companyid`);

--
-- Indexes for table `tblcompany_ojt`
--
ALTER TABLE `tblcompany_ojt`
  ADD PRIMARY KEY (`idnum`);

--
-- Indexes for table `tblcourse`
--
ALTER TABLE `tblcourse`
  ADD PRIMARY KEY (`courseid`);

--
-- Indexes for table `tbldepartment`
--
ALTER TABLE `tbldepartment`
  ADD PRIMARY KEY (`departmentid`);

--
-- Indexes for table `tblendorsement`
--
ALTER TABLE `tblendorsement`
  ADD PRIMARY KEY (`endorsementid`);

--
-- Indexes for table `tblfaculty`
--
ALTER TABLE `tblfaculty`
  ADD PRIMARY KEY (`facultyid`);

--
-- Indexes for table `tblrating`
--
ALTER TABLE `tblrating`
  ADD PRIMARY KEY (`ratingid`);

--
-- Indexes for table `tblreset`
--
ALTER TABLE `tblreset`
  ADD PRIMARY KEY (`resetid`);

--
-- Indexes for table `tblreset_f`
--
ALTER TABLE `tblreset_f`
  ADD PRIMARY KEY (`resetid`);

--
-- Indexes for table `tblsection`
--
ALTER TABLE `tblsection`
  ADD PRIMARY KEY (`sectionid`);

--
-- Indexes for table `tblstudent`
--
ALTER TABLE `tblstudent`
  ADD PRIMARY KEY (`studentid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblaccomplishmentreport`
--
ALTER TABLE `tblaccomplishmentreport`
  MODIFY `reportid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblaccomplishment_photo`
--
ALTER TABLE `tblaccomplishment_photo`
  MODIFY `idnum` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblapplication`
--
ALTER TABLE `tblapplication`
  MODIFY `applicationid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblapplication_tmp`
--
ALTER TABLE `tblapplication_tmp`
  MODIFY `idnum` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `tblcompany`
--
ALTER TABLE `tblcompany`
  MODIFY `companyid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tblcompany_ojt`
--
ALTER TABLE `tblcompany_ojt`
  MODIFY `idnum` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblcourse`
--
ALTER TABLE `tblcourse`
  MODIFY `courseid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbldepartment`
--
ALTER TABLE `tbldepartment`
  MODIFY `departmentid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblendorsement`
--
ALTER TABLE `tblendorsement`
  MODIFY `endorsementid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblfaculty`
--
ALTER TABLE `tblfaculty`
  MODIFY `facultyid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tblrating`
--
ALTER TABLE `tblrating`
  MODIFY `ratingid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tblreset`
--
ALTER TABLE `tblreset`
  MODIFY `resetid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblreset_f`
--
ALTER TABLE `tblreset_f`
  MODIFY `resetid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblsection`
--
ALTER TABLE `tblsection`
  MODIFY `sectionid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tblstudent`
--
ALTER TABLE `tblstudent`
  MODIFY `studentid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
